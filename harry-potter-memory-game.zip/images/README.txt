IMAGE REQUIREMENTS

This game requires character images for each Harry Potter character:
- harry.jpg
- hermione.jpg
- ron.jpg
- dumbledore.jpg
- snape.jpg
- tomriddle.jpg
- ginny.jpg
- cedric.jpg
- luna.jpg
- draco.jpg
- mcgonagall.jpg
- grindelwald.jpg

IMPORTANT: Due to copyright restrictions, you must source these images yourself.
Recommended sources:
1. Official Harry Potter movie stills
2. Creative Commons licensed images
3. Fan art with proper attribution

Image Guidelines:
- Recommended size: 300x300 pixels
- Format: JPEG (.jpg)
- Square aspect ratio preferred
- Clear, recognizable character portraits

Ensure you have the rights to use any images you add to this directory.
